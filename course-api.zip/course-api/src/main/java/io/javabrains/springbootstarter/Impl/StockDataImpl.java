package io.javabrains.springbootstarter.Impl;

import org.springframework.beans.factory.annotation.Autowired;

import io.javabrains.springbootstarter.bpo.StockDatabpo;
import io.javabrains.springbootstarter.model.Stock_Data;
import io.javabrains.springbootstarter.repo.StockDataRepo;

public abstract class StockDataImpl implements StockDatabpo {
	
	@Autowired
	StockDataRepo stockDataRepo;

	@Override
	public Stock_Data getData(String name){
		
		return stockDataRepo.findByStock(name);
	}
}

