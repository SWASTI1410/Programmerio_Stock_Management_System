package io.javabrains.springbootstarter.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.javabrains.springbootstarter.bpo.SegmentDatabpo;
import io.javabrains.springbootstarter.model.Segment_Data;
import io.javabrains.springbootstarter.repo.SegmentDataRepo;
import io.javabrains.springbootstarter.repo.SegmentSqlRepo;




@Service
public abstract class SegmentDataImpl implements SegmentDatabpo{
	
	@Autowired
	SegmentDataRepo segmentDataRepo;
	
	@Autowired
	SegmentSqlRepo segmentSqlRepo;
	
	@Override
	public Segment_Data getData() {
		
		return segmentDataRepo.findByExchangeName("1");
	}
	
}
