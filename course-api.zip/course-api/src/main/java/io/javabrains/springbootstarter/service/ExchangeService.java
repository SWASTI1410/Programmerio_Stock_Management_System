package io.javabrains.springbootstarter.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import io.javabrains.springbootstarter.bpo.ExchangeDatabpo;
import io.javabrains.springbootstarter.model.Exchange_Data;




public class ExchangeService{
	
	 @Autowired
	 private ExchangeDatabpo exchangeDatabpo;
	
	 @PostMapping("/exchanges")
     public List<Exchange_Data> getAllExchange_Data() {
	 return exchangeDatabpo.getAllExchange();
		
}

@RequestMapping("/exchanges/{Name}")
public Optional<Exchange_Data> getExchange_Data(@PathVariable String Name) {
	return exchangeDatabpo.getExchangeData(Name);
}

@RequestMapping(method=RequestMethod.POST, value="/exchanges")
public void addExchange_Data(@RequestBody Exchange_Data exchangeData) {
	exchangeDatabpo.addExchangeData();
	
}
	@RequestMapping(method=RequestMethod.PUT, value="/exchanges/{id}")
public void updateExchange_Data(@RequestBody Exchange_Data topic, @PathVariable String id) {
		exchangeDatabpo.updateExchangeData(id, topic);
}

@RequestMapping(method=RequestMethod.DELETE, value="/exchanges/{id}")
public void deleteExchange_Data(@PathVariable String id) {
	exchangeDatabpo.deleteExchange_Data(id);
}

	
}

