package io.javabrains.springbootstarter.model;

	
		import javax.persistence.*;
		import java.io.Serializable;
        import java.sql.Date;


		@Entity
		@Table(name="Stock_Data")
		public class Stock_Data implements Serializable {

		private static final long serialVersionUID = 1L;

		@Id
		@Column(name = "Symbol")
		private String Symbol;

		@Column(name = "Industry" )
		private String Industry;

		@Column(name = "Segment")
		private String Segment;

		@Column(name = "Exchange")
		private String Exchange;
		
		@Column(name = "Type")
		private String Type;
		
		@Column(name = "Current_Price")
		private Float CurrentPrice;
		
		@Column(name = "Expiry_Date")
		private Date ExpiryDate;
		
		@Column(name = "Lot_Size")
		private int LotSize;

		public String getSymbol() {
			return Symbol;
		}

		public void setSymbol(String symbol) {
			Symbol = symbol;
		}

		public String getIndustry() {
			return Industry;
		}

		public void setIndustry(String industry) {
			Industry = industry;
		}

		public String getSegment() {
			return Segment;
		}

		public void setSegment(String segment) {
			Segment = segment;
		}

		public String getExchange() {
			return Exchange;
		}

		public void setExchange(String exchange) {
			Exchange = exchange;
		}

		public String getType() {
			return Type;
		}

		public void setType(String type) {
			Type = type;
		}

		public Float getCurrentPrice() {
			return CurrentPrice;
		}

		public void setCurrentPrice(Float currentPrice) {
			CurrentPrice = currentPrice;
		}

		public Date getExpiryDate() {
			return ExpiryDate;
		}

		public void setExpiryDate(Date expiryDate) {
			ExpiryDate = expiryDate;
		}

		public int getLotSize() {
			return LotSize;
		}

		public void setLotSize(int lotSize) {
			LotSize = lotSize;
		}
}
