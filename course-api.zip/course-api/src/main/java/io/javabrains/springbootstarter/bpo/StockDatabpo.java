package io.javabrains.springbootstarter.bpo;

import java.util.List;
import java.util.Optional;

import io.javabrains.springbootstarter.model.Stock_Data;

public interface StockDatabpo {
	
	 Stock_Data getData();

	static List<Stock_Data> getAllSegment_Data() {
		// TODO Auto-generated method stub
		return null;
	}

	

	static void addStock_Data() {
		// TODO Auto-generated method stub
		
	}

	static void updateStock_Data(String id, Stock_Data stock_Data) {
		// TODO Auto-generated method stub
		
	}

	static void deleteStock_Data(String id) {
		// TODO Auto-generated method stub
		
	}

	static Optional<Stock_Data> getAllSegment_Data(String exchange_Name) {
		// TODO Auto-generated method stub
		return null;
	}

	Stock_Data getData(String name);

}
