package io.javabrains.springbootstarter.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import io.javabrains.springbootstarter.bpo.ExchangeDatabpo;
import io.javabrains.springbootstarter.model.Exchange_Data;
import io.javabrains.springbootstarter.repo.ExchangeDataRepo;

public class ExchangeDataImpl implements ExchangeDatabpo{

	@Autowired
	ExchangeDataRepo exchangeDataRepo;
    
	@Override
	public Exchange_Data getData(String name){
		
		return exchangeDataRepo.findByStock(name);
	}

	@Override
	public Exchange_Data getData() {
	
		return null;
	}

	@Override
	public List<Exchange_Data> getAllExchange() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Exchange_Data> getExchange(String name) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public void deleteExchange_Data(String id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateExchangeData(String id, Exchange_Data exchangeData) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addExchangeData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Optional<Exchange_Data> getExchangeData(String name) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}
	
}
