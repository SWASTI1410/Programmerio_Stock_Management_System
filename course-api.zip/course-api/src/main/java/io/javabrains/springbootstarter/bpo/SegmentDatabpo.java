package io.javabrains.springbootstarter.bpo;

import java.util.List;
import java.util.Optional;

import io.javabrains.springbootstarter.model.Exchange_Data;
import io.javabrains.springbootstarter.model.Segment_Data;

public interface SegmentDatabpo {
	
	 Segment_Data getData();


	Optional<Exchange_Data> getSegment_Data(String name);

	void addSegment_Data();

	void deleteSegment_Data(String id);

	void updateSegment_Data(String id, Exchange_Data exchangeName);

	List<Segment_Data> getAllSegment_Data();


	Optional<Segment_Data> getAllSegment_Data(String exchangeName);
	
}
