package io.javabrains.springbootstarter.repo;

import java.util.List;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import io.javabrains.springbootstarter.model.Segment_Data;

public abstract class SegmentSqlRepo implements SegmentDataRepo{
	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	   
	public void setDataSource(DataSource dataSource) {
	this.dataSource = dataSource;
	this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}
	
	public void create(String Exchange_Name, Time Start_Time, Time End_Time,String Working_Days) {
	      String insertQuery = "insert into Segment_Data (Exchange_Name, Start_Time, End_Time, Working_Days) values (?, ?)";
	      jdbcTemplateObject.update( insertQuery, Exchange_Name, Start_Time, End_Time, Working_Days);
	      System.out.println("Created Record Exchange_Name = " + Exchange_Name + " Start_Time = " + Start_Time + " End_Time = " + End_Time + " Working_Days = " + Working_Days );
	      return;
	   }

	
	public Segment_Data getSegment_Data(String Exchange_Name) {
	      String SeD = "select * from Segment_Data where Exchange_Name = ?";
	      Segment_Data segment_Data = jdbcTemplateObject.queryForObject(SeD,
	    		  new Object[]{Exchange_Name}, (rs, rownum) -> {return fillStockData(rs);} );
	      return segment_Data;
    }
	
	
    private Segment_Data fillStockData(ResultSet rs)  {
		
    	Segment_Data segmentData = new Segment_Data();
		
		try {
			segmentData.setExchangeName(rs.getString("Exchange_Name"));
			segmentData.setStratTime(rs.getTime("Start_Time"));
			segmentData.setEndTime(rs.getTime("End_Time"));
			segmentData.setWorkingDays(rs.getString("Working_Days"));
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return segmentData;
		
	}
	public void update(String Working_Days){
	      String SeD = "update Segment_Data set Working_Days = ? where Exchange_Name = ?";
	      jdbcTemplateObject.update(SeD, Working_Days);
	      System.out.println("Updated Record Working_Days = " + Working_Days );
	      return;
	   }
	
	  public List<Segment_Data> listSegment_Data() {
	      String SeD = "select * from Segment_Data";
	      List <Segment_Data> segment_Data = jdbcTemplateObject.queryForList(SeD, Segment_Data.class);
	      return segment_Data;
	   }
}
	
