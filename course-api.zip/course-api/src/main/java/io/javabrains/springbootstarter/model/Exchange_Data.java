package io.javabrains.springbootstarter.model;

		
	
		import javax.persistence.*;
		import java.io.Serializable;
         import java.sql.Time;


		@Entity
		@Table(name="Exchange_Data")
		public class Exchange_Data implements Serializable {

		private static final long serialVersionUID = 1L;

		@Id
		@Column(name = "Name")
		private String Name;

		@Column(name = "Symbol")
		private Time Symbol;

		@Column(name = "Country")
		private Time Country;

		public String getName() {
			return Name;
		}

		public void setName(String name) {
			Name = name;
		}

		public Time getSymbol() {
			return Symbol;
		}

		public void setSymbol(Time symbol) {
			Symbol = symbol;
		}

		public Time getCountry() {
			return Country;
		}

		public void setCountry(Time country) {
			Country = country;
		}

		public void setCountry(String string) {
			// TODO Auto-generated method stub
			
		}

		public void setSymbol(String string) {
			// TODO Auto-generated method stub
			
		}
		
		
		
}
