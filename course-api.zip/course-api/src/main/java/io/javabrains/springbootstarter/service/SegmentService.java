package io.javabrains.springbootstarter.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import io.javabrains.springbootstarter.bpo.SegmentDatabpo;
import io.javabrains.springbootstarter.model.Exchange_Data;
import io.javabrains.springbootstarter.model.Segment_Data;




public class SegmentService{
	
	 @Autowired
	 private SegmentDatabpo segmentDatabpo;
	
	 @PostMapping("/segments")
     public List<Segment_Data> getAllSegment_Data() {
	 return segmentDatabpo.getAllSegment_Data();
		
}

@RequestMapping("/segments/{Exchange_Name}")
public Optional<Segment_Data> getExchange_Data(@PathVariable String Exchange_Name) {
	return segmentDatabpo.getAllSegment_Data(Exchange_Name);
}

@RequestMapping(method=RequestMethod.POST, value="/exchanges")
public void addExchange_Data(@RequestBody Exchange_Data exchangeData) {
	segmentDatabpo.addSegment_Data();
	
}
	@RequestMapping(method=RequestMethod.PUT, value="/exchanges/{id}")
public void updateExchange_Data(@RequestBody Exchange_Data Segment_Data, @PathVariable String id) {
		segmentDatabpo.updateSegment_Data(id, Segment_Data);
}

@RequestMapping(method=RequestMethod.DELETE, value="/exchanges/{id}")
public void deleteExchange_Data(@PathVariable String id) {
	segmentDatabpo.deleteSegment_Data(id);
}

	
}

