package io.javabrains.springbootstarter.bpo;

import java.util.List;
import java.util.Optional;

import io.javabrains.springbootstarter.model.Exchange_Data;

public interface ExchangeDatabpo {
	
	Exchange_Data getData();

	Exchange_Data getData(String name);

	List<Exchange_Data> getAllExchange();

	Optional<Exchange_Data> getExchange(String name);

	void deleteExchange_Data(String id);

	void updateExchangeData(String id, Exchange_Data exchangeData);

	void addExchangeData();

	Optional<Exchange_Data> getExchangeData(String name);

	

}
