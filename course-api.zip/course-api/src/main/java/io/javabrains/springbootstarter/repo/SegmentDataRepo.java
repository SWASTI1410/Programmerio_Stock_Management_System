package io.javabrains.springbootstarter.repo;

import org.springframework.data.repository.CrudRepository;

import io.javabrains.springbootstarter.model.Segment_Data;

public interface SegmentDataRepo extends CrudRepository<Segment_Data, String>{
	
	
	
	Segment_Data findBySegmentData(String exchangeName);

	Segment_Data findByExchangeName(String string);

}
