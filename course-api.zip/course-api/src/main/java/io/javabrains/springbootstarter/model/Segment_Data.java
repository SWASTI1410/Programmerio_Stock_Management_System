package io.javabrains.springbootstarter.model;

		
	
		import javax.persistence.*;
		import java.io.Serializable;
        import java.sql.Time;


		@Entity
		@Table(name="Segment_Data")
		public class Segment_Data implements Serializable {

		private static final long serialVersionUID = 1L;

		@Id
		@Column(name = "Exchange_Name")
		private String ExchangeName;

		@Column(name = "Start_Time")
		private Time StratTime;

		@Column(name = "End_Time")
		private Time EndTime;
		
		@Column(name = "Working_Days")
		private String WorkingDays;

		public String getExchangeName() {
			return ExchangeName;
		}

		public void setExchangeName(String exchangeName) {
			ExchangeName = exchangeName;
		}

		public Time getStratTime() {
			return StratTime;
		}

		public void setStratTime(Time stratTime) {
			StratTime = stratTime;
		}

		public Time getEndTime() {
			return EndTime;
		}

		public void setEndTime(Time endTime) {
			EndTime = endTime;
		}

		public String getWorkingDays() {
			return WorkingDays;
		}

		public void setWorkingDays(String workingDays) {
			WorkingDays = workingDays;
		}
}
