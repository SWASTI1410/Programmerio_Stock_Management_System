package io.javabrains.springbootstarter.repo;

import java.util.List;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import io.javabrains.springbootstarter.model.Stock_Data;

public abstract class StockSqlRepo implements StockDataRepo{
	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	   
	public void setDataSource(DataSource dataSource) {
	this.dataSource = dataSource;
	this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}
	
	public void create(String Symbol, String Industry,String Segment, String Exchange, String Type, Float Current_Price,Date Expiry_Date, Integer Lot_Size ) {
	      String insertQuery = "insert into Stock_Data (Symbol, Industry, Segment, Exchange, Type, Current_Price, Expiry_Date, Lot_Size) values (?, ?, ?, ?, ?, ?, ?, ?)";
	      jdbcTemplateObject.update( insertQuery, Symbol, Industry, Segment, Exchange, Type, Current_Price, Expiry_Date, Lot_Size);
	      System.out.println("Created Record Exchange_Name = " + Symbol + " Industry = " + Industry + " Segment = " + Segment + " Exchange = " + Exchange + " Type " + Type + " Current_Price " + Current_Price + " Expiry_Date " + Expiry_Date + " Lot_Size " + Lot_Size);
	      return;
	   }

	
	public Stock_Data getStock_Data(String Symbol) {
	      String SD = "select * from Stock_Data where Type = ?";
	      Stock_Data stock_Data = jdbcTemplateObject.queryForObject(SD, 
	    		  new Object[]{Symbol}, (rs, rownum) -> {return fillStockData(rs);} );
	      return stock_Data;
    }
	
	

	private Stock_Data fillStockData(ResultSet rs)  {
		
		Stock_Data stockData = new Stock_Data();
		
		try {
			stockData.setSymbol(rs.getString("Symbol"));
			stockData.setIndustry(rs.getString("Industry"));
			stockData.setCurrentPrice(rs.getFloat("Current_Price"));
			stockData.setExchange(rs.getString("Exchange"));
			stockData.setExpiryDate(rs.getDate("Expiry_Date"));
			stockData.setLotSize(rs.getInt("Lot_Size"));
			stockData.setSegment(rs.getString("Segment"));
			stockData.setType(rs.getString("Type"));
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return stockData;
		
	}
	
	public void update(String Current_Price){
	      String SD = "update Stock_Data set Current_Price = ? where Symbol = ?";
	      jdbcTemplateObject.update(SD, Current_Price);
	      System.out.println("Updated Record Working_Days = " + Current_Price );
	      return;
	   }
	
	  public List<Stock_Data> listStock_Data() {
	      String SD = "select * from Stock_Data";
	      List <Stock_Data> stock_Data = jdbcTemplateObject.queryForList(SD, Stock_Data.class);
	      return stock_Data;
	   }

}
	
