package io.javabrains.springbootstarter.repo;

import org.springframework.data.repository.CrudRepository;

import io.javabrains.springbootstarter.model.Stock_Data;

public interface StockDataRepo extends CrudRepository<Stock_Data, String> {
	
	Stock_Data findByStock(String name);

}
