package io.javabrains.springbootstarter.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import io.javabrains.springbootstarter.bpo.StockDatabpo;
import io.javabrains.springbootstarter.model.Stock_Data;




public class StockService{
	
	 @Autowired
	 private StockDatabpo stockDatabpo;
	
	 @PostMapping("/segments")
     public List<Stock_Data> getAllSegment_Data() {
	 return StockDatabpo.getAllSegment_Data();
		
}

@RequestMapping("/segments/{Exchange_Name}")
public Optional<Stock_Data> getStock_Data(@PathVariable String Exchange_Name) {
	return StockDatabpo.getAllSegment_Data(Exchange_Name);
}

@RequestMapping(method=RequestMethod.POST, value="/exchanges")
public void addExchange_Data(@RequestBody Stock_Data stock_Data) {
	StockDatabpo.addStock_Data();
	
}
	@RequestMapping(method=RequestMethod.PUT, value="/exchanges/{id}")
public void updateExchange_Data(@RequestBody Stock_Data Stock_Data, @PathVariable String id) {
		StockDatabpo.updateStock_Data(id, Stock_Data);
}

@RequestMapping(method=RequestMethod.DELETE, value="/exchanges/{id}")
public void deleteExchange_Data(@PathVariable String id) {
	StockDatabpo.deleteStock_Data(id);
}

	
}

