package io.javabrains.springbootstarter.repo;

import java.util.List;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import io.javabrains.springbootstarter.model.Exchange_Data;
import io.javabrains.springbootstarter.model.Segment_Data;

public abstract class ExchangeSqlRepo implements ExchangeDataRepo{
	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	   
	public void setDataSource(DataSource dataSource) {
	this.dataSource = dataSource;
	this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}
	
	public void create(String Name, String Symbol, String Country) {
	      String insertQuery = "insert into Exchange_Data (Name, Symbol, Country) values (?, ?, ?)";
	      jdbcTemplateObject.update( insertQuery, Name, Symbol, Country);
	      System.out.println("Created Record Name = " + Name + " Symbol = " + Symbol + " Country = " + Country);
	      return;
	   }

	
	public Exchange_Data getExchange_Data(String Name) {
	      String ED = "select * from Exchange_Data where Name = ?";
	      Exchange_Data exchange_Data = jdbcTemplateObject.queryForObject(ED, 
	    		  new Object[]{Name}, (rs, rownum) -> {return fillStockData(rs);} );
	     
	      return exchange_Data;
    }
	
	 private Exchange_Data fillStockData(ResultSet rs)  {
			
		 Exchange_Data exchangeData = new Exchange_Data();
			
			try {
				exchangeData.setName(rs.getString("Name"));
				exchangeData.setSymbol(rs.getString("Symbol"));
				exchangeData.setCountry(rs.getString("Country"));
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
			return exchangeData;
			
		}
	
	public void update(String Country){
	      String ED = "update Exchange_Data set age = ? where Name = ?";
	      jdbcTemplateObject.update(ED, Country);
	      System.out.println("Updated Record Country = " + Country );
	      return;
	   }
	
	  public List<Exchange_Data> listSegment_Data() {
	      String ED = "select * from Exchange_Data";
	      List <Exchange_Data> segment_Data = jdbcTemplateObject.queryForList(ED, Exchange_Data.class);
	      return segment_Data;
	   }
}
	
