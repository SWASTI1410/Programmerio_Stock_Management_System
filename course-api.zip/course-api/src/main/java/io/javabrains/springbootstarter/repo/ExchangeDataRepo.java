package io.javabrains.springbootstarter.repo;

import org.springframework.data.repository.CrudRepository;

import io.javabrains.springbootstarter.model.Exchange_Data;



public interface ExchangeDataRepo extends CrudRepository<Exchange_Data, String>{

	Exchange_Data findByExchangeData(String name);

	Exchange_Data findByStock(String name);


	 
}